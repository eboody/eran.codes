export default {
  "--palette-hue": "250",
  "--palette-hue-rotate-by": "0",
  "--palette-chroma": "0.15",
  "--color-1":
    "oklch(98% calc(0.03 * var(--palette-chroma)) calc(var(--palette-hue) + (0 * var(--palette-hue-rotate-by))))",
  "--color-2":
    "oklch(97% calc(0.06 * var(--palette-chroma)) calc(var(--palette-hue) + (1 * var(--palette-hue-rotate-by))))",
  "--color-3":
    "oklch(93% calc(0.1 * var(--palette-chroma)) calc(var(--palette-hue) + (2 * var(--palette-hue-rotate-by))))",
  "--color-4":
    "oklch(84% calc(0.12 * var(--palette-chroma)) calc(var(--palette-hue) + (3 * var(--palette-hue-rotate-by))))",
  "--color-5":
    "oklch(80% calc(0.16 * var(--palette-chroma)) calc(var(--palette-hue) + (4 * var(--palette-hue-rotate-by))))",
  "--color-6":
    "oklch(71% calc(0.19 * var(--palette-chroma)) calc(var(--palette-hue) + (5 * var(--palette-hue-rotate-by))))",
  "--color-7":
    "oklch(66% calc(0.2 * var(--palette-chroma)) calc(var(--palette-hue) + (6 * var(--palette-hue-rotate-by))))",
  "--color-8":
    "oklch(58% calc(0.21 * var(--palette-chroma)) calc(var(--palette-hue) + (7 * var(--palette-hue-rotate-by))))",
  "--color-9":
    "oklch(53% calc(0.2 * var(--palette-chroma)) calc(var(--palette-hue) + (8 * var(--palette-hue-rotate-by))))",
  "--color-10":
    "oklch(49% calc(0.19 * var(--palette-chroma)) calc(var(--palette-hue) + (9 * var(--palette-hue-rotate-by))))",
  "--color-11":
    "oklch(42% calc(0.17 * var(--palette-chroma)) calc(var(--palette-hue) + (10 * var(--palette-hue-rotate-by))))",
  "--color-12":
    "oklch(35% calc(0.15 * var(--palette-chroma)) calc(var(--palette-hue) + (11 * var(--palette-hue-rotate-by))))",
  "--color-13":
    "oklch(27% calc(0.12 * var(--palette-chroma)) calc(var(--palette-hue) + (12 * var(--palette-hue-rotate-by))))",
  "--color-14":
    "oklch(20% calc(0.09 * var(--palette-chroma)) calc(var(--palette-hue) + (13 * var(--palette-hue-rotate-by))))",
  "--color-15":
    "oklch(16% calc(0.07 * var(--palette-chroma)) calc(var(--palette-hue) + (14 * var(--palette-hue-rotate-by))))",
  "--color-16":
    "oklch(10% calc(0.05 * var(--palette-chroma)) calc(var(--palette-hue) + (15 * var(--palette-hue-rotate-by))))",
};
