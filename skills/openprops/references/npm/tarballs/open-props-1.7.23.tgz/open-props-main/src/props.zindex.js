export default {
  '--layer-1': 1,
  '--layer-2': 2,
  '--layer-3': 3,
  '--layer-4': 4,
  '--layer-5': 5,
  '--layer-important': 2147483647,  
}
